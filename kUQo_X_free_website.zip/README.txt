kUQo X FREE STARTER WEBSITE
============================

1. Open index.html in a browser to preview.
2. Replace the three "PRODUCT PHOTO" boxes with your real product images when you have them.
3. Change product names and prices inside index.html.
4. The order form currently sends the order to WhatsApp number 01745872016.
5. Before public launch, replace the WhatsApp number if needed and add your final social links.
6. For a free launch, upload index.html to any static hosting service that supports free sites.
7. This is a starter storefront, not a full inventory/payment system. Stock can be connected later.
